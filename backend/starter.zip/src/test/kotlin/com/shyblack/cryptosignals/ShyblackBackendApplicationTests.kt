package com.shyblack.cryptosignals

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ShyblackBackendApplicationTests {

	@Test
	fun contextLoads() {
	}

}
