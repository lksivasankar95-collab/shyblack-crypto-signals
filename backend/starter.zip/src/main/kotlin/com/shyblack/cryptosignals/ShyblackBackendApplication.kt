package com.shyblack.cryptosignals

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ShyblackBackendApplication

fun main(args: Array<String>) {
	runApplication<ShyblackBackendApplication>(*args)
}
