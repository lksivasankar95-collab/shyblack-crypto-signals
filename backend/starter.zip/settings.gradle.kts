rootProject.name = "cryptosignals"
